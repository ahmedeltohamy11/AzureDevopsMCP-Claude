import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import * as azdev from "azure-devops-node-api";
import { WorkItemTrackingApi } from "azure-devops-node-api/WorkItemTrackingApi.js";
import {
  WorkItemExpand,
  WorkItemErrorPolicy,
} from "azure-devops-node-api/interfaces/WorkItemTrackingInterfaces.js";
import * as fs from "fs";
import * as path from "path";

const ORG_URL = process.env.ADO_ORG_URL!;
const PAT = process.env.ADO_PAT!;

if (!ORG_URL || !PAT) {
  console.error("Missing ADO_ORG_URL or ADO_PAT environment variables.");
  process.exit(1);
}

function getConnection() {
  const authHandler = azdev.getPersonalAccessTokenHandler(PAT);
  return new azdev.WebApi(ORG_URL, authHandler);
}

// ─── Fuzzy normalizer ─────────────────────────────────────────────────────────

function normalize(s: string): string {
  return s.toLowerCase().replace(/[\s\-_\.]/g, "");
}

function fuzzyMatch(input: string, candidates: string[]): string {
  const n = normalize(input);
  // 1. Exact match
  const exact = candidates.find(c => c === input);
  if (exact) return exact;
  // 2. Case-insensitive exact
  const caseInsensitive = candidates.find(c => c.toLowerCase() === input.toLowerCase());
  if (caseInsensitive) return caseInsensitive;
  // 3. Normalized exact (strips spaces, dashes, underscores)
  const normalized = candidates.find(c => normalize(c) === n);
  if (normalized) return normalized;
  // 4. Normalized contains
  const contains = candidates.find(c => normalize(c).includes(n) || n.includes(normalize(c)));
  if (contains) return contains;
  // 5. Word-by-word: all input words appear in candidate
  const words = n.match(/[a-z0-9]+/g) ?? [];
  const wordMatch = candidates.find(c => {
    const cn = normalize(c);
    return words.every(w => cn.includes(w));
  });
  if (wordMatch) return wordMatch;
  // No match — return original and let ADO throw a meaningful error
  return input;
}

// Cache to avoid repeated API calls within a session
const _cache: Record<string, string[]> = {};

async function resolveProject(input: string): Promise<string> {
  if (!_cache["projects"]) {
    const conn = getConnection();
    const coreApi = await conn.getCoreApi();
    const projects = await coreApi.getProjects();
    _cache["projects"] = projects.map((p: any) => p.name);
  }
  return fuzzyMatch(input, _cache["projects"]);
}

async function resolveWorkItemState(project: string, workItemType: string, input: string): Promise<string> {
  const key = `states:${project}:${workItemType}`;
  if (!_cache[key]) {
    const witApi = await getWitApi();
    const type = await witApi.getWorkItemType(project, workItemType);
    _cache[key] = (type.transitions ?? {}) 
      ? Object.keys(type.transitions ?? {}).concat(
          (type.states ?? []).map((s: any) => s.name)
        )
      : [];
    // fallback: get states from work item type directly
    if (_cache[key].length === 0) {
      const states = await witApi.getWorkItemTypeStates(project, workItemType);
      _cache[key] = states.map((s: any) => s.name);
    }
  }
  return fuzzyMatch(input, _cache[key]);
}

async function resolveStateForItem(itemId: number, inputState: string): Promise<string> {
  try {
    const witApi = await getWitApi();
    const item = await witApi.getWorkItem(itemId, ["System.TeamProject", "System.WorkItemType"]);
    const project = item.fields?.["System.TeamProject"];
    const type = item.fields?.["System.WorkItemType"];
    if (project && type) return resolveWorkItemState(project, type, inputState);
  } catch {}
  return inputState;
}

async function getWitApi(): Promise<WorkItemTrackingApi> {
  return getConnection().getWorkItemTrackingApi();
}

// Test Plans REST helper (not fully covered by the node SDK)
async function testPlansRequest(method: string, project: string, apiPath: string, body?: any) {
  const url = `${ORG_URL}/${encodeURIComponent(project)}/_apis/${apiPath}${apiPath.includes("?") ? "&" : "?"}api-version=7.1`;
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    Accept: "application/json",
    Authorization: `Basic ${Buffer.from(`:${PAT}`).toString("base64")}`,
  };
  const res = await fetch(url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`ADO API error ${res.status}: ${text}`);
  return text ? JSON.parse(text) : {};
}

const server = new Server(
  { name: "ado-mcp", version: "2.0.0" },
  { capabilities: { tools: {} } }
);

// ─── Tool definitions ─────────────────────────────────────────────────────────

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    // ── Work Items ──────────────────────────────────────────────────────────
    {
      name: "get_work_item",
      description: "Get a single work item by ID with all fields expanded.",
      inputSchema: {
        type: "object",
        properties: {
          id: { type: "number" },
          project: { type: "string" },
        },
        required: ["id"],
      },
    },
    {
      name: "get_work_items",
      description: "Get multiple work items by IDs.",
      inputSchema: {
        type: "object",
        properties: {
          ids: { type: "array", items: { type: "number" } },
          project: { type: "string" },
        },
        required: ["ids"],
      },
    },
    {
      name: "query_work_items",
      description: "Run a WIQL query to search/filter work items.",
      inputSchema: {
        type: "object",
        properties: {
          wiql: { type: "string" },
          project: { type: "string" },
          top: { type: "number" },
        },
        required: ["wiql"],
      },
    },
    {
      name: "create_work_item",
      description: "Create a new work item of any type (Bug, Task, User Story, Epic, Feature, Test Case, etc.).",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          type: { type: "string" },
          title: { type: "string" },
          description: { type: "string" },
          assigned_to: { type: "string" },
          area_path: { type: "string" },
          iteration_path: { type: "string" },
          priority: { type: "number" },
          tags: { type: "string" },
          parent_id: { type: "number" },
          extra_fields: { type: "object", additionalProperties: true },
        },
        required: ["project", "type", "title"],
      },
    },
    {
      name: "update_work_item",
      description: "Update any fields on an existing work item.",
      inputSchema: {
        type: "object",
        properties: {
          id: { type: "number" },
          title: { type: "string" },
          description: { type: "string" },
          state: { type: "string" },
          assigned_to: { type: "string" },
          area_path: { type: "string" },
          iteration_path: { type: "string" },
          priority: { type: "number" },
          tags: { type: "string" },
          extra_fields: { type: "object", additionalProperties: true },
        },
        required: ["id"],
      },
    },
    {
      name: "add_tags",
      description: "Add tags to a work item without removing existing ones.",
      inputSchema: {
        type: "object",
        properties: {
          id: { type: "number" },
          tags: { type: "array", items: { type: "string" } },
        },
        required: ["id", "tags"],
      },
    },
    {
      name: "add_comment",
      description: "Post a comment on a work item.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          id: { type: "number" },
          text: { type: "string" },
        },
        required: ["project", "id", "text"],
      },
    },
    {
      name: "get_comments",
      description: "Get all comments on a work item.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          id: { type: "number" },
        },
        required: ["project", "id"],
      },
    },
    {
      name: "attach_file",
      description: "Attach a file to a work item by local file path.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          id: { type: "number" },
          file_path: { type: "string" },
          file_name: { type: "string" },
          comment: { type: "string" },
        },
        required: ["project", "id", "file_path"],
      },
    },
    {
      name: "attach_screenshot",
      description: "Attach a screenshot to a work item by local file path.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          id: { type: "number" },
          file_path: { type: "string" },
          file_name: { type: "string" },
          comment: { type: "string" },
        },
        required: ["project", "id", "file_path"],
      },
    },
    {
      name: "add_link",
      description: "Link two work items together.",
      inputSchema: {
        type: "object",
        properties: {
          source_id: { type: "number" },
          target_id: { type: "number" },
          link_type: { type: "string" },
          comment: { type: "string" },
        },
        required: ["source_id", "target_id", "link_type"],
      },
    },
    {
      name: "delete_work_item",
      description: "Delete a work item (recycle bin by default).",
      inputSchema: {
        type: "object",
        properties: {
          id: { type: "number" },
          project: { type: "string" },
          destroy: { type: "boolean" },
        },
        required: ["id", "project"],
      },
    },
    {
      name: "get_work_item_types",
      description: "List all work item types in a project.",
      inputSchema: {
        type: "object",
        properties: { project: { type: "string" } },
        required: ["project"],
      },
    },
    {
      name: "get_work_item_fields",
      description: "List all fields for a work item type.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          type: { type: "string" },
        },
        required: ["project", "type"],
      },
    },
    {
      name: "list_projects",
      description: "List all projects in the organization.",
      inputSchema: { type: "object", properties: {} },
    },
    {
      name: "get_iterations",
      description: "Get all iterations/sprints for a team.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          team: { type: "string" },
        },
        required: ["project"],
      },
    },
    {
      name: "get_areas",
      description: "Get all area paths for a project.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          depth: { type: "number" },
        },
        required: ["project"],
      },
    },
    {
      name: "get_board_columns",
      description: "Get columns of a team board.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          team: { type: "string" },
          board: { type: "string" },
        },
        required: ["project", "team", "board"],
      },
    },
    {
      name: "get_board_items",
      description: "Get all work items on a team board.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          team: { type: "string" },
          board: { type: "string" },
        },
        required: ["project", "team", "board"],
      },
    },

    // ── Test Plans ──────────────────────────────────────────────────────────
    {
      name: "list_test_plans",
      description: "List all test plans in a project.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string", description: "Project name" },
          active_only: { type: "boolean", description: "Return only active plans (default false)" },
        },
        required: ["project"],
      },
    },
    {
      name: "get_test_plan",
      description: "Get details of a specific test plan.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
        },
        required: ["project", "plan_id"],
      },
    },
    {
      name: "create_test_plan",
      description: "Create a new test plan.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          name: { type: "string" },
          area_path: { type: "string" },
          iteration: { type: "string" },
          start_date: { type: "string", description: "ISO date string (optional)" },
          end_date: { type: "string", description: "ISO date string (optional)" },
          description: { type: "string" },
        },
        required: ["project", "name"],
      },
    },
    {
      name: "update_test_plan",
      description: "Update an existing test plan.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
          name: { type: "string" },
          area_path: { type: "string" },
          iteration: { type: "string" },
          start_date: { type: "string" },
          end_date: { type: "string" },
          description: { type: "string" },
          state: { type: "string", description: "e.g. Active, Inactive" },
        },
        required: ["project", "plan_id"],
      },
    },
    {
      name: "list_test_suites",
      description: "List all test suites in a test plan.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
        },
        required: ["project", "plan_id"],
      },
    },
    {
      name: "get_test_suite",
      description: "Get details of a specific test suite.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
          suite_id: { type: "number" },
        },
        required: ["project", "plan_id", "suite_id"],
      },
    },
    {
      name: "create_test_suite",
      description: "Create a test suite inside a test plan. Types: staticTestSuite, dynamicTestSuite (query-based), requirementTestSuite.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
          parent_suite_id: { type: "number", description: "Parent suite ID (use root suite ID if unsure)" },
          name: { type: "string" },
          suite_type: {
            type: "string",
            description: "staticTestSuite | dynamicTestSuite | requirementTestSuite",
          },
          query_string: { type: "string", description: "WIQL query for dynamicTestSuite" },
          requirement_id: { type: "number", description: "Work item ID for requirementTestSuite" },
        },
        required: ["project", "plan_id", "parent_suite_id", "name", "suite_type"],
      },
    },
    {
      name: "update_test_suite",
      description: "Update a test suite name or query.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
          suite_id: { type: "number" },
          name: { type: "string" },
          query_string: { type: "string" },
        },
        required: ["project", "plan_id", "suite_id"],
      },
    },
    {
      name: "list_test_cases",
      description: "List all test cases in a test suite.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
          suite_id: { type: "number" },
        },
        required: ["project", "plan_id", "suite_id"],
      },
    },
    {
      name: "add_test_cases_to_suite",
      description: "Add existing test case work item IDs to a test suite.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
          suite_id: { type: "number" },
          test_case_ids: { type: "array", items: { type: "number" }, description: "Work item IDs of test cases" },
        },
        required: ["project", "plan_id", "suite_id", "test_case_ids"],
      },
    },
    {
      name: "remove_test_case_from_suite",
      description: "Remove a test case from a test suite.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
          suite_id: { type: "number" },
          test_case_id: { type: "number" },
        },
        required: ["project", "plan_id", "suite_id", "test_case_id"],
      },
    },
    {
      name: "create_test_case",
      description: "Create a new Test Case work item with steps.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          title: { type: "string" },
          steps: {
            type: "array",
            description: "Test steps array",
            items: {
              type: "object",
              properties: {
                action: { type: "string", description: "Step action/description" },
                expected: { type: "string", description: "Expected result" },
              },
              required: ["action"],
            },
          },
          area_path: { type: "string" },
          iteration_path: { type: "string" },
          assigned_to: { type: "string" },
          priority: { type: "number" },
          tags: { type: "string" },
          description: { type: "string" },
          suite_id: { type: "number", description: "Optionally add to this suite after creation" },
          plan_id: { type: "number", description: "Required if suite_id is provided" },
        },
        required: ["project", "title"],
      },
    },
    {
      name: "update_test_case_steps",
      description: "Update the steps of an existing test case work item.",
      inputSchema: {
        type: "object",
        properties: {
          id: { type: "number", description: "Test case work item ID" },
          steps: {
            type: "array",
            items: {
              type: "object",
              properties: {
                action: { type: "string" },
                expected: { type: "string" },
              },
              required: ["action"],
            },
          },
        },
        required: ["id", "steps"],
      },
    },
    {
      name: "list_test_runs",
      description: "List test runs in a project.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number", description: "Filter by plan ID (optional)" },
          is_automated: { type: "boolean", description: "Filter automated/manual (optional)" },
          top: { type: "number", description: "Max results (default 20)" },
        },
        required: ["project"],
      },
    },
    {
      name: "get_test_run",
      description: "Get details of a specific test run.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          run_id: { type: "number" },
        },
        required: ["project", "run_id"],
      },
    },
    {
      name: "create_test_run",
      description: "Create a new test run for a test plan.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          name: { type: "string" },
          plan_id: { type: "number" },
          suite_ids: { type: "array", items: { type: "number" }, description: "Suite IDs to include (optional)" },
          configuration_ids: { type: "array", items: { type: "number" }, description: "Config IDs (optional)" },
          is_automated: { type: "boolean", description: "Default false" },
          build_id: { type: "number", description: "Associated build (optional)" },
        },
        required: ["project", "name", "plan_id"],
      },
    },
    {
      name: "update_test_run",
      description: "Update state or details of a test run.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          run_id: { type: "number" },
          state: { type: "string", description: "NotStarted | InProgress | Completed | Aborted | Waiting" },
          comment: { type: "string" },
        },
        required: ["project", "run_id"],
      },
    },
    {
      name: "list_test_results",
      description: "List test results (test points) in a test run.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          run_id: { type: "number" },
        },
        required: ["project", "run_id"],
      },
    },
    {
      name: "update_test_results",
      description: "Record pass/fail/etc outcomes for test cases in a run.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          run_id: { type: "number" },
          results: {
            type: "array",
            items: {
              type: "object",
              properties: {
                id: { type: "number", description: "Test result ID from list_test_results" },
                outcome: { type: "string", description: "Passed | Failed | Blocked | NotApplicable | NotExecuted" },
                comment: { type: "string" },
                error_message: { type: "string" },
                duration_in_ms: { type: "number" },
              },
              required: ["id", "outcome"],
            },
          },
        },
        required: ["project", "run_id", "results"],
      },
    },
    {
      name: "list_test_points",
      description: "List test points (test case + configuration combos) in a suite.",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
          suite_id: { type: "number" },
        },
        required: ["project", "plan_id", "suite_id"],
      },
    },
    {
      name: "update_test_points",
      description: "Update test point properties (e.g. assign tester, reset outcome).",
      inputSchema: {
        type: "object",
        properties: {
          project: { type: "string" },
          plan_id: { type: "number" },
          suite_id: { type: "number" },
          point_ids: { type: "array", items: { type: "number" } },
          tester: { type: "string", description: "Tester display name or email (optional)" },
          outcome: { type: "string", description: "Passed | Failed | Blocked | NotApplicable | NotExecuted (optional)" },
        },
        required: ["project", "plan_id", "suite_id", "point_ids"],
      },
    },
    {
      name: "list_test_configurations",
      description: "List all test configurations in a project.",
      inputSchema: {
        type: "object",
        properties: { project: { type: "string" } },
        required: ["project"],
      },
    },
  ],
}));

// ─── Helpers ──────────────────────────────────────────────────────────────────

function buildStepsXml(steps: { action: string; expected?: string }[]): string {
  const inner = steps
    .map(
      (s, i) =>
        `<step id="${i + 2}" type="ActionStep">` +
        `<parameterizedString isformatted="true">${s.action}</parameterizedString>` +
        `<parameterizedString isformatted="true">${s.expected ?? ""}</parameterizedString>` +
        `<description/></step>`
    )
    .join("");
  return `<steps id="0" last="${steps.length + 1}">${inner}</steps>`;
}

// ─── Tool handlers ────────────────────────────────────────────────────────────

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;
  const a = args as Record<string, any>;

  try {
    const conn = getConnection();
    const witApi = await getWitApi();

    // ── get_work_item ──────────────────────────────────────────────────────
    if (name === "get_work_item") {
      const item = await witApi.getWorkItem(a.id, undefined, undefined, WorkItemExpand.All);
      return { content: [{ type: "text", text: JSON.stringify(item, null, 2) }] };
    }

    // ── get_work_items ─────────────────────────────────────────────────────
    if (name === "get_work_items") {
      const items = await witApi.getWorkItems(a.ids, undefined, undefined, WorkItemExpand.All, WorkItemErrorPolicy.Omit);
      return { content: [{ type: "text", text: JSON.stringify(items, null, 2) }] };
    }

    // ── query_work_items ───────────────────────────────────────────────────
    if (name === "query_work_items") {
      const project = a.project ? await resolveProject(a.project) : undefined;
      const result = await witApi.queryByWiql({ query: a.wiql }, project ? { project } : undefined, undefined, a.top ?? 50);
      const ids = (result.workItems ?? []).map((wi: any) => wi.id as number).filter(Boolean);
      if (ids.length === 0) return { content: [{ type: "text", text: "No work items found." }] };
      const items = await witApi.getWorkItems(ids, undefined, undefined, WorkItemExpand.Fields, WorkItemErrorPolicy.Omit);
      return { content: [{ type: "text", text: JSON.stringify(items, null, 2) }] };
    }

    // ── create_work_item ───────────────────────────────────────────────────
    if (name === "create_work_item") {
      a.project = await resolveProject(a.project);
      const patch: any[] = [{ op: "add", path: "/fields/System.Title", value: a.title }];
      if (a.description) patch.push({ op: "add", path: "/fields/System.Description", value: a.description });
      if (a.assigned_to) patch.push({ op: "add", path: "/fields/System.AssignedTo", value: a.assigned_to });
      if (a.area_path) patch.push({ op: "add", path: "/fields/System.AreaPath", value: a.area_path });
      if (a.iteration_path) patch.push({ op: "add", path: "/fields/System.IterationPath", value: a.iteration_path });
      if (a.priority) patch.push({ op: "add", path: "/fields/Microsoft.VSTS.Common.Priority", value: a.priority });
      if (a.tags) patch.push({ op: "add", path: "/fields/System.Tags", value: a.tags });
      if (a.extra_fields) for (const [k, v] of Object.entries(a.extra_fields)) patch.push({ op: "add", path: `/fields/${k}`, value: v });
      if (a.parent_id) patch.push({ op: "add", path: "/relations/-", value: { rel: "System.LinkTypes.Hierarchy-Reverse", url: `${ORG_URL}/_apis/wit/workItems/${a.parent_id}` } });
      const item = await witApi.createWorkItem(null, patch, a.project, a.type);
      return { content: [{ type: "text", text: JSON.stringify(item, null, 2) }] };
    }

    // ── update_work_item ───────────────────────────────────────────────────
    if (name === "update_work_item") {
      const patch: any[] = [];
      if (a.title) patch.push({ op: "add", path: "/fields/System.Title", value: a.title });
      if (a.description) patch.push({ op: "add", path: "/fields/System.Description", value: a.description });
      if (a.state) {
        const resolvedState = await resolveStateForItem(a.id, a.state);
        patch.push({ op: "add", path: "/fields/System.State", value: resolvedState });
      }
      if (a.assigned_to) patch.push({ op: "add", path: "/fields/System.AssignedTo", value: a.assigned_to });
      if (a.area_path) patch.push({ op: "add", path: "/fields/System.AreaPath", value: a.area_path });
      if (a.iteration_path) patch.push({ op: "add", path: "/fields/System.IterationPath", value: a.iteration_path });
      if (a.priority) patch.push({ op: "add", path: "/fields/Microsoft.VSTS.Common.Priority", value: a.priority });
      if (a.tags) patch.push({ op: "add", path: "/fields/System.Tags", value: a.tags });
      if (a.extra_fields) for (const [k, v] of Object.entries(a.extra_fields)) patch.push({ op: "add", path: `/fields/${k}`, value: v });
      if (patch.length === 0) return { content: [{ type: "text", text: "No fields to update." }] };
      const item = await witApi.updateWorkItem(null, patch, a.id);
      return { content: [{ type: "text", text: JSON.stringify(item, null, 2) }] };
    }

    // ── add_tags ───────────────────────────────────────────────────────────
    if (name === "add_tags") {
      const existing = await witApi.getWorkItem(a.id, ["System.Tags"]);
      const current: string = existing.fields?.["System.Tags"] ?? "";
      const currentSet = new Set(current.split(";").map((t: string) => t.trim()).filter(Boolean));
      for (const t of a.tags) currentSet.add(t.trim());
      const merged = [...currentSet].join("; ");
      const item = await witApi.updateWorkItem(null, [{ op: "add", path: "/fields/System.Tags", value: merged }], a.id);
      return { content: [{ type: "text", text: `Tags updated: ${merged}\n\n${JSON.stringify(item, null, 2)}` }] };
    }

    // ── add_comment ────────────────────────────────────────────────────────
    if (name === "add_comment") {
      const comment = await witApi.addComment({ text: a.text }, a.project, a.id);
      return { content: [{ type: "text", text: JSON.stringify(comment, null, 2) }] };
    }

    // ── get_comments ───────────────────────────────────────────────────────
    if (name === "get_comments") {
      const comments = await witApi.getComments(a.project, a.id);
      return { content: [{ type: "text", text: JSON.stringify(comments, null, 2) }] };
    }

    // ── attach_file / attach_screenshot ───────────────────────────────────
    if (name === "attach_file" || name === "attach_screenshot") {
      const filePath = a.file_path as string;
      if (!fs.existsSync(filePath)) return { content: [{ type: "text", text: `File not found: ${filePath}` }], isError: true };
      const fileName = a.file_name ?? path.basename(filePath);
      const stream = fs.createReadStream(filePath);
      const attachRef = await witApi.createAttachment(null, a.project, fileName, undefined, undefined, stream as any);
      if (!attachRef?.url) return { content: [{ type: "text", text: "Attachment upload failed." }], isError: true };
      const patch = [{ op: "add", path: "/relations/-", value: { rel: "AttachedFile", url: attachRef.url, attributes: { comment: a.comment ?? (name === "attach_screenshot" ? "Screenshot" : "Attached file") } } }];
      const item = await witApi.updateWorkItem(null, patch, a.id);
      return { content: [{ type: "text", text: `Attached "${fileName}" to work item #${a.id}.\n\n${JSON.stringify(item, null, 2)}` }] };
    }

    // ── add_link ───────────────────────────────────────────────────────────
    if (name === "add_link") {
      const patch = [{ op: "add", path: "/relations/-", value: { rel: a.link_type, url: `${ORG_URL}/_apis/wit/workItems/${a.target_id}`, attributes: { comment: a.comment ?? "" } } }];
      const item = await witApi.updateWorkItem(null, patch, a.source_id);
      return { content: [{ type: "text", text: JSON.stringify(item, null, 2) }] };
    }

    // ── delete_work_item ───────────────────────────────────────────────────
    if (name === "delete_work_item") {
      await witApi.deleteWorkItem(a.id, a.project, a.destroy ?? false);
      return { content: [{ type: "text", text: `Work item #${a.id} deleted${a.destroy ? " permanently" : " (recycle bin)"}.` }] };
    }

    // ── get_work_item_types ────────────────────────────────────────────────
    if (name === "get_work_item_types") {
      const types = await witApi.getWorkItemTypes(a.project);
      return { content: [{ type: "text", text: JSON.stringify(types.map((t: any) => ({ name: t.name, description: t.description })), null, 2) }] };
    }

    // ── get_work_item_fields ───────────────────────────────────────────────
    if (name === "get_work_item_fields") {
      const fields = await witApi.getWorkItemTypeFieldsWithReferences(a.project, a.type);
      return { content: [{ type: "text", text: JSON.stringify(fields, null, 2) }] };
    }

    // ── list_projects ──────────────────────────────────────────────────────
    if (name === "list_projects") {
      const coreApi = await conn.getCoreApi();
      const projects = await coreApi.getProjects();
      return { content: [{ type: "text", text: JSON.stringify(projects.map((p: any) => ({ id: p.id, name: p.name, state: p.state })), null, 2) }] };
    }

    // ── get_iterations ─────────────────────────────────────────────────────
    if (name === "get_iterations") {
      const workApi = await conn.getWorkApi();
      const iterations = await workApi.getTeamIterations({ project: a.project, team: a.team });
      return { content: [{ type: "text", text: JSON.stringify(iterations, null, 2) }] };
    }

    // ── get_areas ──────────────────────────────────────────────────────────
    if (name === "get_areas") {
      const areas = await witApi.getClassificationNode(a.project, 1, undefined, a.depth ?? 10);
      return { content: [{ type: "text", text: JSON.stringify(areas, null, 2) }] };
    }

    // ── get_board_columns ──────────────────────────────────────────────────
    if (name === "get_board_columns") {
      const workApi = await conn.getWorkApi();
      const columns = await workApi.getBoardColumns({ project: a.project, team: a.team }, a.board);
      return { content: [{ type: "text", text: JSON.stringify(columns, null, 2) }] };
    }

    // ── get_board_items ────────────────────────────────────────────────────
    if (name === "get_board_items") {
      const workApi = await conn.getWorkApi();
      const board = await workApi.getBoard({ project: a.project, team: a.team }, a.board);
      return { content: [{ type: "text", text: JSON.stringify(board, null, 2) }] };
    }

    // ══ TEST PLANS ══════════════════════════════════════════════════════════

    // ── list_test_plans ────────────────────────────────────────────────────
    if (name === "list_test_plans") {
      a.project = await resolveProject(a.project);
      const q = a.active_only ? "?filterActivePlans=true" : "";
      const data = await testPlansRequest("GET", a.project, `testplan/plans${q}`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── get_test_plan ──────────────────────────────────────────────────────
    if (name === "get_test_plan") {
      const data = await testPlansRequest("GET", a.project, `testplan/plans/${a.plan_id}`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── create_test_plan ───────────────────────────────────────────────────
    if (name === "create_test_plan") {
      const body: any = { name: a.name };
      if (a.area_path) body.areaPath = a.area_path;
      if (a.iteration) body.iteration = a.iteration;
      if (a.start_date) body.startDate = a.start_date;
      if (a.end_date) body.endDate = a.end_date;
      if (a.description) body.description = a.description;
      const data = await testPlansRequest("POST", a.project, `testplan/plans`, body);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── update_test_plan ───────────────────────────────────────────────────
    if (name === "update_test_plan") {
      const body: any = {};
      if (a.name) body.name = a.name;
      if (a.area_path) body.areaPath = a.area_path;
      if (a.iteration) body.iteration = a.iteration;
      if (a.start_date) body.startDate = a.start_date;
      if (a.end_date) body.endDate = a.end_date;
      if (a.description) body.description = a.description;
      if (a.state) body.state = a.state;
      const data = await testPlansRequest("PATCH", a.project, `testplan/plans/${a.plan_id}`, body);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── list_test_suites ───────────────────────────────────────────────────
    if (name === "list_test_suites") {
      const data = await testPlansRequest("GET", a.project, `testplan/plans/${a.plan_id}/suites?asTreeView=true`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── get_test_suite ─────────────────────────────────────────────────────
    if (name === "get_test_suite") {
      const data = await testPlansRequest("GET", a.project, `testplan/plans/${a.plan_id}/suites/${a.suite_id}`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── create_test_suite ──────────────────────────────────────────────────
    if (name === "create_test_suite") {
      const body: any = {
        name: a.name,
        suiteType: a.suite_type,
        parentSuite: { id: a.parent_suite_id },
      };
      if (a.query_string) body.queryString = a.query_string;
      if (a.requirement_id) body.requirementId = a.requirement_id;
      const data = await testPlansRequest("POST", a.project, `testplan/plans/${a.plan_id}/suites`, body);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── update_test_suite ──────────────────────────────────────────────────
    if (name === "update_test_suite") {
      const body: any = {};
      if (a.name) body.name = a.name;
      if (a.query_string) body.queryString = a.query_string;
      const data = await testPlansRequest("PATCH", a.project, `testplan/plans/${a.plan_id}/suites/${a.suite_id}`, body);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── list_test_cases ────────────────────────────────────────────────────
    if (name === "list_test_cases") {
      const data = await testPlansRequest("GET", a.project, `testplan/plans/${a.plan_id}/suites/${a.suite_id}/testcase`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── add_test_cases_to_suite ────────────────────────────────────────────
    if (name === "add_test_cases_to_suite") {
      const body = (a.test_case_ids as number[]).map((id) => ({ workItem: { id } }));
      const data = await testPlansRequest("POST", a.project, `testplan/plans/${a.plan_id}/suites/${a.suite_id}/testcase`, body);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    // ── remove_test_case_from_suite ────────────────────────────────────────
    if (name === "remove_test_case_from_suite") {
      await testPlansRequest("DELETE", a.project, `testplan/plans/${a.plan_id}/suites/${a.suite_id}/testcase/${a.test_case_id}`);
      return { content: [{ type: "text", text: `Test case #${a.test_case_id} removed from suite ${a.suite_id}.` }] };
    }

    // ── create_test_case ───────────────────────────────────────────────────
    if (name === "create_test_case") {
      const patch: any[] = [{ op: "add", path: "/fields/System.Title", value: a.title }];
      if (a.steps && a.steps.length > 0) patch.push({ op: "add", path: "/fields/Microsoft.VSTS.TCM.Steps", value: buildStepsXml(a.steps) });
      if (a.description) patch.push({ op: "add", path: "/fields/System.Description", value: a.description });
      if (a.area_path) patch.push({ op: "add", path: "/fields/System.AreaPath", value: a.area_path });
      if (a.iteration_path) patch.push({ op: "add", path: "/fields/System.IterationPath", value: a.iteration_path });
      if (a.assigned_to) patch.push({ op: "add", path: "/fields/System.AssignedTo", value: a.assigned_to });
      if (a.priority) patch.push({ op: "add", path: "/fields/Microsoft.VSTS.Common.Priority", value: a.priority });
      if (a.tags) patch.push({ op: "add", path: "/fields/System.Tags", value: a.tags });
      const item = await witApi.createWorkItem(null, patch, a.project, "Test Case");
      if (a.suite_id && a.plan_id && item.id) {
        await testPlansRequest("POST", a.project, `testplan/plans/${a.plan_id}/suites/${a.suite_id}/testcase`, [{ workItem: { id: item.id } }]);
      }
      return { content: [{ type: "text", text: JSON.stringify(item, null, 2) }] };
    }

    // ── update_test_case_steps ─────────────────────────────────────────────
    if (name === "update_test_case_steps") {
      const stepsXml = buildStepsXml(a.steps);
      const item = await witApi.updateWorkItem(null, [{ op: "add", path: "/fields/Microsoft.VSTS.TCM.Steps", value: stepsXml }], a.id);
      return { content: [{ type: "text", text: JSON.stringify(item, null, 2) }] };
    }

    // ── list_test_runs ─────────────────────────────────────────────────────
    if (name === "list_test_runs") {
      let q = `?top=${a.top ?? 20}`;
      if (a.plan_id) q += `&planId=${a.plan_id}`;
      if (a.is_automated !== undefined) q += `&isAutomated=${a.is_automated}`;
      const data = await testPlansRequest("GET", a.project, `test/runs${q}`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    if (name === "get_test_run") {
      const data = await testPlansRequest("GET", a.project, `test/runs/${a.run_id}`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    if (name === "create_test_run") {
      const body: any = { name: a.name, plan: { id: a.plan_id }, isAutomated: a.is_automated ?? false };
      if (a.suite_ids) body.testSuites = a.suite_ids.map((id: number) => ({ id }));
      if (a.configuration_ids) body.configurationIds = a.configuration_ids;
      if (a.build_id) body.build = { id: a.build_id };
      const data = await testPlansRequest("POST", a.project, `test/runs`, body);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    if (name === "update_test_run") {
      const body: any = {};
      if (a.state) body.state = a.state;
      if (a.comment) body.comment = a.comment;
      const data = await testPlansRequest("PATCH", a.project, `test/runs/${a.run_id}`, body);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    if (name === "list_test_results") {
      const data = await testPlansRequest("GET", a.project, `test/runs/${a.run_id}/results`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    if (name === "update_test_results") {
      const body = a.results.map((r: any) => {
        const obj: any = { id: r.id, outcome: r.outcome, state: "Completed" };
        if (r.comment) obj.comment = r.comment;
        if (r.error_message) obj.errorMessage = r.error_message;
        if (r.duration_in_ms) obj.durationInMs = r.duration_in_ms;
        return obj;
      });
      const data = await testPlansRequest("PATCH", a.project, `test/runs/${a.run_id}/results`, body);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    if (name === "list_test_points") {
      const data = await testPlansRequest("GET", a.project, `testplan/plans/${a.plan_id}/suites/${a.suite_id}/TestPoint`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    if (name === "update_test_points") {
      const body: any = { testPointIds: a.point_ids };
      if (a.tester) body.tester = { displayName: a.tester };
      if (a.outcome) body.outcome = a.outcome;
      const data = await testPlansRequest("PATCH", a.project, `testplan/plans/${a.plan_id}/suites/${a.suite_id}/TestPoint`, body);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    if (name === "list_test_configurations") {
      const data = await testPlansRequest("GET", a.project, `testplan/configurations`);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }

    return { content: [{ type: "text", text: `Unknown tool: ${name}` }], isError: true };

  } catch (err: any) {
    return {
      content: [{ type: "text", text: `Error: ${err?.message ?? String(err)}` }],
      isError: true,
    };
  }
});

// ─── Start ────────────────────────────────────────────────────────────────────

const transport = new StdioServerTransport();
await server.connect(transport);
console.error("Azure DevOps MCP server running.");